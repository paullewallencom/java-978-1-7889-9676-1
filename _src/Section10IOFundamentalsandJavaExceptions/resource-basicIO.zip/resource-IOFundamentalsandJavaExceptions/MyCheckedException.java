
public class MyCheckedException extends Exception
{

}
