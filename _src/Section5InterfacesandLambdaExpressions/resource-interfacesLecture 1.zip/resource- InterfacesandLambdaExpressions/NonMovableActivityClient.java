
public interface NonMovableActivityClient extends ActivityClient, Test
{
	void onUseRequested();
}
