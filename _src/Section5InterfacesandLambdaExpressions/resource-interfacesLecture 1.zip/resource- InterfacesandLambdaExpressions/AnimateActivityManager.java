
public class AnimateActivityManager
{
	public void accept(ActivityClient item)
	{
		item.doSomething(0);
	}
}
