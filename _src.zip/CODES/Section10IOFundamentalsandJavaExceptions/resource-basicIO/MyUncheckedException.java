
public class MyUncheckedException extends RuntimeException
{
	
}
