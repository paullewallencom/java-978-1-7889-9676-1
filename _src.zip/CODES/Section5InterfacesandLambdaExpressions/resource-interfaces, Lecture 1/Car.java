public class Car implements ActivityClient, Test
{
	@Override
	public void doSomething()
	{
		System.out.println("I am a car");
	}

	@Override
	public void test()
	{
	}
}
