
public interface Test
{
	public void test();
}
